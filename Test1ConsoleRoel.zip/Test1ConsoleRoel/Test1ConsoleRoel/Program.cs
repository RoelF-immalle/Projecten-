﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test1ConsoleRoel
{
    class Program
    {
        static void Main(string[] args)
        {
            Double x = 3;
            Double y = 1;
            Console.WriteLine(x + y);
            Console.WriteLine(x + 1);
            Console.WriteLine(1 + x);

            var a = 10.5;
            var b = 3.3;
            Console.WriteLine(a %  b) ;
        }
    }
}
