﻿namespace Euhm
{
    internal class Children
    {
    }
}